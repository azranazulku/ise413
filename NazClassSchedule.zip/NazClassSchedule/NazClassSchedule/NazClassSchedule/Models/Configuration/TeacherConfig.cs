﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NazClassSchedule.Models.DomainModels;

namespace NazClassSchedule.Models.Configuration
{
    public class TeacherConfig : IEntityTypeConfiguration<Teacher>
    {
        public void Configure(EntityTypeBuilder<Teacher> entity)
        {
            entity.HasData(
                new Teacher { TeacherId = 1, FirstName = "Ali", LastName="Yılmaz"},
                new Teacher { TeacherId = 2, FirstName = "Ayşe", LastName = "Yılmaz" },
                new Teacher { TeacherId = 3, FirstName = "Rick", LastName = "Morty" },
                new Teacher { TeacherId = 4, FirstName = "Bojack", LastName = "Horseman" },
                new Teacher { TeacherId = 5, FirstName = "Katniss", LastName = "Everdeen" }
                );
        }
    }
}
